import requests

def fetch_price_data(category: str, commodity: str):
    """
    從政府開放資料 API 獲取指定分類和商品的價格數據。
    :param category: 商品分類名稱
    :param commodity: 商品名稱
    :return: JSON 格式的價格數據
    """
    response = requests.get(
        "https://opendata.ey.gov.tw/api/ConsumerProtection/NecessitiesPrice",
        params={"CategoryName": category, "Name": commodity},
    )
    response.raise_for_status()  # 如果請求失敗，拋出 HTTPError
    return response.json()
