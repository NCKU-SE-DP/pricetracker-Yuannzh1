from pydantic import BaseModel

class PriceQuery(BaseModel):
    """
    查詢價格的請求參數模型，包括分類和商品名稱。
    """
    category: str
    commodity: str

class PriceResponse(BaseModel):
    """
    回應價格查詢的數據模型，包括商品名稱、價格和日期。
    """
    item: str
    price: float
    date: str
