from fastapi import APIRouter, Query
from .dependencies import fetch_price_data
from .schemas import PriceQuery, PriceResponse
import requests
router = APIRouter(prefix="/api/v1/prices", tags=["prices"])

@router.get("/necessities", response_model=PriceResponse)
def get_necessities_prices(
        category=Query(None), commodity=Query(None)
):
    return requests.get(
        "https://opendata.ey.gov.tw/api/ConsumerProtection/NecessitiesPrice",
        params={"CategoryName": category, "Name": commodity},
    ).json()
